from django.shortcuts import render
from django.http import HttpResponse

def t1(request):
    return HttpResponse('<h2>Hello Brother</h2>')
def t2(request):
    return HttpResponse('<h2>Hello Sister</h2>')
def t3(request):
    return HttpResponse('<h2>Hello Father</h2>')
def t4(request):
    return render(request,'uk1.html')

