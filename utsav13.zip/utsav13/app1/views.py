from django.shortcuts import render
import datetime
t=datetime.datetime.now()
def a1f(req):
    return render(req,'app1/ap1.html',{'Time':(t.hour,':',t.minute)})
# Create your views here.
