from django.shortcuts import render
import datetime
t=datetime.datetime.now()
def a2f(req):
    return render(req,'app2/ap2.html',{'Date':t})

# Create your views here.
