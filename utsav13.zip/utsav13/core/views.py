from django.shortcuts import render
import datetime
tm=datetime.datetime.now()
def f1core(req):
    return render(req,'core/hpg.htm',{'Time':tm})
# Create your views here.
