from django.shortcuts import render
import datetime
tm=datetime.datetime.now()
def fap1(req):
    return render(req,'ap1.html',{'Time':'%s : %s'%(tm.hour,tm.minute),'val':999})
def fap2(req):
    return render(req,'ap2.html',{'Date':tm.date})
def fcore(req):
    return render(req,'hpg.htm',{'Time':tm})
# Create your views here.
