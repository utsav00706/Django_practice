from django.shortcuts import render
def app1f1(req):
    return render(req,'app1.html')
# Create your views here.
