from django.shortcuts import render
def app2f1(req):
    return render(req,'app2.html')
# Create your views here.
