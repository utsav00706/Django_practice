from django.shortcuts import render
#from django.http import HttpResponse
def fdjango(request):
    udict={'Myname':'Utsav Kumar', 'wife':'Shweta Jaiswal'}
    #return render(request,'fees1.html',context=udict)
    return render(request,'fees/fees1.html',udict)

def fpython(request):
    return render(request,'fees/fees2.html')
# Create your views here.
