from django.urls import path
from fees import views
urlpatterns = [
    path('f1/', views.fdjango),
    path('f2/', views.fpython), 
]