from django.shortcuts import render
#from django.http import HttpResponse
def cdjango(request):
    return render(request,'course/course1.html')

def cpython(request):
    dictp={'ua':'Mydear dosto','ub':'My Friend Ganesha'}
    return render(request,'course/course2.html',dictp)

# Create your views here.
