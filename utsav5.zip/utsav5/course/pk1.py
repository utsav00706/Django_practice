a=9
b=8
print(a+b)