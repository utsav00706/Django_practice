from django.urls import path
from course import views
urlpatterns = [
    path('c1/', views.cdjango),
    path('c2/', views.cpython), 
]