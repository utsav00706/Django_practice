from django.urls import path
from . import views
urlpatterns = [
    path('paper/', views.app2view),
]