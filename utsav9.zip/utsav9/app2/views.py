from django.shortcuts import render
def app2view(request):
    d2={'stu1':{'name':'rohit','age':39,'course':'BE'},
        'stu2':{'name':'manish','age':32,'course':'BSc'},
        'stu3':{'name':'rahul','age':29,'course':'Mtech'}}
    return render(request,'ppr.html',{'t1':['goku','gohan','chacha', 'chikki'],'Students':d2 }) 