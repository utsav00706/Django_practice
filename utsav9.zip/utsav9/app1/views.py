from django.shortcuts import render

def app1view(request):
    return render(request,'pg1.html',{'name':'utsav', 'age':39, 'area':'Kerla', 'compony':'Techno'}) 
# Create your views here.
