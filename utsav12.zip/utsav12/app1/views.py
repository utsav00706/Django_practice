from django.shortcuts import render
import datetime
now = datetime.datetime.now()
def f1(reqest):
    return render(reqest, 'app1/ap1.html', {'date':now})
# Create your views here.
