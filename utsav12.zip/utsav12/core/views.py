from django.shortcuts import render
def hmpg(req):
    return render(req,'hm.html')
# Create your views here.
