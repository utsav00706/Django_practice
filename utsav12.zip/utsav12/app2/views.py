from django.shortcuts import render
import datetime
e = datetime.datetime.now()
now=(e.hour, e.minute, e.second)
def f1(reqest):
    return render(reqest, 'app2/ap2.html', {'time':now})

# Create your views here.
