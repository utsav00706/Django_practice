from django.shortcuts import render
from django.http import HttpResponse

def f1fees(request):
    return render(request,'html/home.html')


# Create your views here.
