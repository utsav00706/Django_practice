from django.shortcuts import render
from django.http import HttpResponse

def f1course(request):
    return HttpResponse('<h4>App-2 function-1</h4>')

def f2course(request):
    return HttpResponse('<h5>App-2 function-1</h5>')

def f3course(request):
    return HttpResponse('<h6>App-3 function-1</h6>')

# Create your views here.
