from django.urls import path
from course import views
urlpatterns = [
    path('f1crs/',views.f1course ),
    path('f2crs/',views.f2course ),
    path('f3crs/',views.f3course ),
]