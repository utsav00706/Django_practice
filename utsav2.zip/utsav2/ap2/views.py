from django.shortcuts import render
from django.http import HttpResponse
##home page##
def hmpg(request):
    return HttpResponse('Home')
def learn_django(request):
    return HttpResponse('Hello Utsav')
def learn_python(request):
    return HttpResponse('<h1>Hello Utsav</h1>')
def learn_var(request):
    return HttpResponse('<h2>Hello UKM</h2>')
def learn_vmath(request):
    #a=int(input())
    b=18+5
    return HttpResponse(b)
# Create your views here.
