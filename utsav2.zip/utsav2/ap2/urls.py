from django.urls import path
from ap2 import views as v1
urlpatterns = [
    path('', v1.hmpg),  # home page of site
    path('pathurluk/', v1.learn_django),
    path('urlpathuk/', v1.learn_python),
    path('third/', v1.learn_var),
    path('forth/', v1.learn_vmath),
]
