from django.urls import path
from ap1 import views as v2

urlpatterns = [
    path('', v2.try1),
    path('six/', v2.try2),
]
