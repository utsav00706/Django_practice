from django.shortcuts import render
from django.http import HttpResponse

def try1(request):
    return HttpResponse('Hello, world. 0c512406 is the polls index.')
def try2(request):
    return HttpResponse('Dusri Application')
# Create your views here.