from django.shortcuts import render
def app2f1(request):
    return render(request,'app2/app2.html',{'fees':5000})

# Create your views here.
