from django.shortcuts import render

def app1f1(request):
    return render(request,'app1/app1.html',{'fees':10000})
# Create your views here.
