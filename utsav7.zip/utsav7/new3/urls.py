from django.urls import path
from . import views
urlpatterns = [
    path('pg2/', views.app3)
]