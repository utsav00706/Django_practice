from django.shortcuts import render
from django.http import HttpResponse

def app3(reqobject):
    return HttpResponse('<h1>BYE</h1>')
# Create your views here.
