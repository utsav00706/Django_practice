from django.shortcuts import render
from django.http import HttpResponse

def app2(reqobject):
    return HttpResponse('<h1>hello</h1>')