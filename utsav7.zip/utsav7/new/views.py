from django.shortcuts import render
from django.http import HttpResponse

def app1(reqobject):
    return HttpResponse('<h1>hi</h1>')
# Create your views here.
