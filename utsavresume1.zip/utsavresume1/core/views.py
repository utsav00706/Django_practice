from django.shortcuts import render
def findex(req):
    return render(req,'index.html')
def fabout(req):
    return render(req,'about.html')
def fcontact(req):
    return render(req,'contact.html')
def fresume(req):
    return render(req,'resume.html')
def fservice(req):
    return render(req,'service.html')

# Create your views here.
