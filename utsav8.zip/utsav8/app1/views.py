from django.shortcuts import render
from django.http import HttpResponse

def view1(reqobject):
    return HttpResponse('hello utsav in app1')

# Create your views here.
