from django.shortcuts import render
from django.http import HttpResponse

def view2(reqobject):
    return HttpResponse('hello utsav in app2')