from django.shortcuts import render
from django.http import HttpResponse

def home(reqobject):
    return HttpResponse('hello utsav at home page')

def home1(reqobject):
    return HttpResponse('<h1>hello utsav at home1 page</h1>')

def home2(reqobject):
    return HttpResponse('<h2  style="color:red">hello utsav at home2 page</h2>')
# Create your views here.
